Question #1:
a. Inline > Embedded/Internal > External
b. Padding clears an area around the content. Margin clears an area outside the border

Question #2:
a. '!==' is a strict inequality operator, so type comparison is performed; whereas '!=' is not strict and type is not checked
b. F

Question #3:
console.log(a1); 	// [1,2]
console.log(a1); 	// [1,2]

Question #4:

document
|__html
	|__head
	|	|__title
	|		|__text: "My Page"
	|
	|__body
		|__img
		|	|__width
		|	|__height
		|	|__src
		|
		|__p
			|__span
			|	|__text: "My Name"
			|__text: "and My Info"